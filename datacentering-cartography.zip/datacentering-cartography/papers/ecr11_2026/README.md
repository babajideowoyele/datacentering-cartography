# ECR11 2026 — Towards a Cartography of Datacentering

This folder contains the materials presented at the *Research Policy* 11th
Online Conference for Early Career Researchers, 27 April 2026.

## Contents

- [`../../slides/slides.md`](../../slides/slides.md) — slide source
- [`../../slides/slides.pdf`](../../slides/slides.pdf) — rendered slides
- `abstract.md` — submitted abstract (this file folder)
- `talk_notes.md` — speaker notes / timing plan
- `qa_prep.md` — anticipated questions and prepared responses

## Presentation slot

| Field | Value |
|-------|-------|
| Conference | RP 11th Online Conference for ECRs |
| Date | 27 April 2026 |
| Slot | 14:27–14:39 BST |
| Format | 10 min talk + 2 min Q&A |
| Chair | Alex Coad |
