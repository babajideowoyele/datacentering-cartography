# Towards a Cartography of Datacentering

**A Multimodal Research Agenda for Innovation Studies**

Babajide Alamu Owoyele
DRIFT, Erasmus University Rotterdam | Radboud University Donders Institute

---

## Abstract

Hyperscale data-center buildout — projected at $750B in capex for 2026 alone —
is reshaping regional electricity systems, sectoral innovation regimes, and
the geopolitics of compute sovereignty. Yet innovation studies lacks an
integrative framework for the *infrastructural and methodological* turn this
buildout demands. This paper proposes a **cartography of datacentering**:
a multi-arena mapping methodology that bridges *Research Policy*'s
existing canon (arenas of development, transitions, sectoral and regional
systems) with the digital-trace methods being developed in adjacent
disciplines (situational analysis, issue mapping, computationally intensive
theory construction).

The cartography integrates four data modalities — news discourse (text),
satellite imagery (image), hyperlink networks (graph), and Crunchbase / 10-K
filings (structured) — through a CITC-anchored workflow that yields
testable propositions across three programs: regional innovation systems
(Loudoun, Luleå, Dublin, Hyderabad), sectoral transformation (hyperscaler
vertical integration), and policy sovereignty (UK AI Growth Zones, EU AI
Factories, France €109B, Saudi HUMAIN, UAE Stargate).

The contribution is twofold: a substantive research agenda for an
under-theorized but rapidly-consolidating arena, and a replicable
methodological toolkit for mapping other contested infrastructure
transitions (energy, telecom, rare earths, supply chains).
