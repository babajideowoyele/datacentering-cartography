# Q&A Preparation — ECR11

The format: 2 minutes for Q&A, **all questions, no answers** during the
slot (per conference rules). RP editors give feedback via mic or chat;
non-presenters via chat. Chat log is distributed afterwards.

So this doc is for:
1. Anticipating what's coming in chat.
2. Preparing tight verbal *acknowledgments* (not answers) during the live slot.
3. Drafting written follow-up replies for after the chat log circulates.

## Likely questions and prepared lines

### Q1 — "Isn't this just STS theory dressed up as innovation studies?"
*(Most likely from an RP editor.)*

**Live acknowledgment:** "Fair concern — let me note that I'm using
Jørgensen and Marres specifically because they bridge to RP and *ST&HV*,
not because I'm importing critical theory wholesale."

**Written follow-up:** Slide 13 makes this explicit. The methodological
spine — CITC (Berente, Seidel & Safadi 2019; Miranda et al. 2022) — comes
from MIS Quarterly and ISR, not from STS. The agenda is testable, not
hermeneutic.

### Q2 — "Where's the empirical contribution? This looks like a methods proposal."
*(Likely from an RP editor.)*

**Live:** "Right — the ECR conference paper is the agenda. The Loudoun pilot
study (slide 14) is the first empirical instantiation; I can speak to that."

**Written:** Loudoun is in progress. The cartography is being built
case-by-case; the agenda paper exists to make the methodology citable
*before* the empirical papers, so reviewers of those empirical papers have
a coherent framework to reference. (This is a deliberate sequencing move.)

### Q3 — "Why CITC and not, say, computational social science more broadly?"

**Live:** "Because CITC's lexical-framing requirement is what makes the
output theoretical, not just descriptive. That's the test for RP."

**Written:** CITC explicitly distinguishes patterns from contributions.
That's the discipline that protects against the most common reviewer
objection to digital-trace work — "this is interesting, but what's the
theoretical contribution?"

### Q4 — "How is this different from existing critical data-center scholarship in *Big Data & Society*?"

**Live:** "Two differences: (1) explicit integration with RP-canon arena and
transitions theory; (2) testable propositions about regional and sectoral
innovation systems, not critique."

**Written:** BD&S work (Hogan, Velkova, Rone) is excellent but doesn't
generate hypotheses about productivity spillovers, labor markets, or sectoral
lock-in. The cartography is designed to interface with *that* set of RP
questions.

### Q5 — "Loudoun, Luleå, Dublin, Hyderabad — why those four?"

**Live:** "Variation on three dimensions: regulatory regime, energy mix, and
historical industrial trajectory. Loudoun is the mature US case; Luleå is
renewable-energy-led; Dublin is FDI-platform; Hyderabad is the emerging
South Asian hub."

**Written:** [Same; expand with citations to comparative case-selection
literature.]

### Q6 — "Crunchbase coverage of sovereign capital is weak. How do you handle Saudi/UAE?"

**Live:** "Acknowledged limitation. Triangulation via PIF/Mubadala
disclosures, press releases, and regulatory filings — documented in the
methods folder. Will likely need a separate paper on sovereign-capital data
gaps."

**Written:** The repo has a methods/sna/README and data/crunchbase/README
explicitly flagging this as an open problem. Pitchbook + CB Insights
triangulation is the planned partial fix; the deeper issue (uneven
disclosure regimes for sovereign vehicles) is itself a substantive finding.

### Q7 — "What's the role of LLMs / AI in the methodology?"

**Live:** "Two roles: bootstrap for situational-map drafting from corpora,
under hand-curation; and contextual topic modeling (BERTopic). Not in the
analysis layer — that's where CITC's lexical framing keeps a human in the
loop."

### Q8 — "Why now, urgency-wise?"

**Live:** "Stargate, PJM auction prices, Maine moratorium, DeepSeek — all in
the last 18 months. The arena is forming *now*. Cartography is more useful
during formation than after consolidation."

### Q9 — "How does this relate to GPT/general purpose technology literature?"

**Live:** "Adjacent but different. GPT lit is about diffusion and
productivity. This is about the *infrastructure that makes the GPT
possible* — and how that infrastructure is contested. Complementary, not
competing."

### Q10 — Skeptical: "Isn't 'datacentering' just a buzzword?"

**Live:** "It's a working term — meant to name the *process*, not the
*facility*. Open to better names. The phenomenon — contested, multi-actor,
infrastructural buildout — is what matters."

## Contingency for tough live moment

If asked something I genuinely don't have an answer for during the live slot:

> "That's a real question and I don't have a satisfying answer in 30
> seconds — let me think on it and follow up in chat / by email."

This is *strictly better* than improvising. RP editors respect honesty about
limits.

## Contact line for follow-up

End any in-chat reply with:

> Repo and methods documentation: github.com/<user>/datacentering-cartography.
> Open to issues, suggestions, and collaboration.
