# Talk Notes & Timing Plan — ECR11

**Total speaking time: 10:00. Q&A: 2:00.**

The talk has 13 main slides (1–13), one backup (14), one closing prompt (15).
Pacing target: ~45 seconds per slide on average, but slides are *not* equal
weight. Plan below.

## Section pacing

| Slides | Section | Target | Cumulative |
|--------|---------|-------:|-----------:|
| 1      | Title   |   0:15 |       0:15 |
| 2–3    | Empirical moment | 1:30 | 1:45 |
| 4      | Gap | 0:45 | 2:30 |
| 5–7    | Theory stack | 2:30 | 5:00 |
| 8      | Methods | 1:15 | 6:15 |
| 9–11   | Three research agendas | 2:30 | 8:45 |
| 12     | What this enables | 0:30 | 9:15 |
| 13     | Why RP | 0:30 | 9:45 |
| 15     | Closing prompt | 0:15 | 10:00 |

Slide 14 (Loudoun cartography) is **backup only** — for Q&A.

## Per-slide cues

### 1. Title (0:15)
Greet, name, affiliation, *what* the talk does in one sentence:
"I'm proposing a methodological cartography for studying data-center
infrastructure as a contested innovation arena."

### 2. The Empirical Moment (0:45)
**Lead with the $750B number.** Don't read the table — point at it.
"Hyperscaler capex is the largest concentrated infrastructure build of our
lifetimes, and it's happening in three years."

### 3. Why Now? (0:45)
Five bullets, two seconds each. The point is *the arena is contested right
now*: Stargate, PJM prices, Maine moratorium, Loudoun rezoning, DeepSeek.
"This is not a stable industry settling — it's a contested arena in
formation."

### 4. The Gap (0:45)
RP has the tools — arenas, transitions, sectoral systems. *Critical
data-center studies* exists in BD&S and *Convergence*, but outside RP.
Nobody has bridged them. **That's the gap.**

### 5. Jørgensen / Arenas (0:50)
Arenas, not levels. Flat ontology. **Negotiation** is the process.
"Hyperscalers, grid operators, communities, workers, regulators are
co-constitutive — not hierarchically ordered."

### 6. Clarke / Situational Analysis (0:50)
Three maps. The key innovation is **implicated actors** — silenced
*and* discursively constructed. "Who is excluded from the negotiation?
Communities, visa workers. Who is invoked but absent? 'The consumer,'
'future generations.'"

### 7. Marres + CITC (0:50) ⚠️ DENSE — DO NOT READ THE FOUR STEPS
**One sentence to land:**
> "Marres tells us *what* to trace. CITC tells us *how* to trace it
> rigorously enough to make a theoretical contribution."

If you have time, mention lexical framing as the discipline that prevents
atheoretical pattern-mining. Skip the four CITC processes — they're on the
slide for editors who screenshot it.

### 8. Methods (1:15)
Four data sources, four expected outputs. **Don't read the slide.** Point at
each row, name it, name what it produces. Close with: "Each modality runs
through the CITC cycle. This is operationalized, not theoretical."

### 9–11. Three Research Agendas (0:50 each)
Same structure each time: question → cases → metrics → expected figures.
Don't dwell. These are *programs* the cartography enables.

### 12. What This Enables (0:30)
Five bullets in 30 seconds. The toolkit move: this isn't only datacentering.
It applies to energy, telecom, rare earths, supply chains — any contested
infrastructure transition.

### 13. Why RP (0:30)
Two columns. **We use your canon. We avoid your desk-rejection triggers.**
Five seconds per bullet. Smile. This is the closing case.

### 15. Closing Prompt (0:15)
Read the question slowly. Hold the silence for one beat. Then: "What are
others?"

## What to skip if time is short

- Slide 4 → 30 seconds, not 45.
- Slide 6 (Clarke) is the most cuttable theory slide if you're behind by
  slide 6 — collapse to "Clarke gives us situational maps and the concept of
  implicated actors."
- Slides 9–11 — collapse to one of the three if needed.

## What to slow down on

- Slide 8 — let the modality grid land.
- Slide 7 — the Marres + CITC sentence is the methodological spine.
