# Working Paper 2: Hyperscaler Vertical Integration and Sectoral Innovation

**Status:** Stub.

## Central question

How does hyperscaler vertical integration (compute → foundational models →
application stacks) reshape sectoral innovation systems, especially in
AI-using industries?

## Mechanism

Hyperscalers (AWS, Google, Meta, Microsoft, increasingly Oracle) are
integrating across:
1. **Physical compute** — owned data-center capacity.
2. **Foundational models** — owned, partner-shared, or invested.
3. **Application stacks** — APIs, agents, vertical SaaS.

This integration changes:
- Startup access to infrastructure (lower friction, deeper lock-in).
- Innovation incentives (build-on-platform vs. build-independent).
- Exit pathways (acquisition into hyperscaler ecosystems).

## Methods

- Crunchbase startup funding networks (hyperscaler-mediated vs. traditional VC).
- Hyperlink/discourse analysis of "platform dependency" framings.
- 10-K extraction of hyperscaler partnership and acquisition patterns.

## Expected figures

- `figures/paper_figures/sectoral_funding_sna.pdf`
- `figures/paper_figures/exit_pathways_temporal.pdf`
- `figures/paper_figures/platform_dependency_framings.pdf`

## Target journal

*Research Policy*. Backup: *Industrial and Corporate Change*, *Strategic
Management Journal*.

## Open work

- Define operational boundary of "hyperscaler-mediated" funding.
- Cross-reference with EU AI Act dependency-disclosure provisions.
