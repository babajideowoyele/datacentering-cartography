# Working Paper 3: Sovereign Compute and Energy Lock-in

**Status:** Stub.

## Central question

What policy mix sustains sovereign compute capacity without replicating
fossil-fuel dependence or geopolitical lock-in?

## Cases

| Programme | Country/Region | Scale | Distinctive feature |
|---|---|---|---|
| AI Growth Zones | UK | TBD | Dedicated zoning + grid commitments |
| AI Factories | EU | €multi-bn | Public-private compute consortia |
| France 2030 | France | €109B | Vertically-integrated investment package |
| HUMAIN | Saudi Arabia | TBD | PIF-backed; tied to Vision 2030 |
| Stargate | UAE / OpenAI | $500B / 7 GW | Cross-border, partner-led |

## Policy instruments to compare

- Tax incentives (capex, energy, employment)
- Grid access and grid-building mandates
- Renewable energy requirements
- Labor standards (visa, training)
- Foreign-investment screening

## Methods

- Policy document discourse analysis (CITC).
- Capital flow networks per programme (Crunchbase + sovereign disclosures).
- Regulatory filing timelines.

## Expected figures

- `figures/paper_figures/sovereign_capital_flows.pdf`
- `figures/paper_figures/policy_discourse_sna.pdf`
- `figures/paper_figures/policy_diffusion_curves.pdf`

## Target journal

*Research Policy*. Backup: *Energy Policy*, *Review of International Political
Economy*.

## Open work

- Sovereign-capital data gap mitigation (see `data/crunchbase/README.md`).
- Comparison framework with prior sovereign-tech programmes (Japan METI,
  Korea CHIPS-equivalents).
