# Working Paper 1: Hyperscale Data Centers and Regional Innovation Systems

**Status:** Stub. Loudoun pilot in progress.

## Central question

How do hyperscale data-center clusters reshape local productivity spillovers,
labor markets, energy regimes, and property relations?

## Cases (planned)

| Region | Type | Distinctive feature |
|---|---|---|
| Loudoun County, US | Mature US cluster | World's densest DC corridor; rezoning conflict 2025 |
| Luleå, Sweden | Renewable-energy-led | Hydropower attractor; arctic cooling |
| Dublin, Ireland | FDI-platform | Tax-policy attractor; grid-connection moratorium |
| Hyderabad, India | Emerging South Asian hub | State-led; HUMAIN-adjacent; rapid growth |

## Methods

- News topic modeling per region (`methods/topic_modeling/`)
- Satellite change detection (`methods/satellite_change/`)
- Crunchbase + 10-K financial mapping (`methods/sna/`)
- Situational maps per case (`methods/situational_maps/`)

## Expected figures

- `figures/paper_figures/regional_topic_drift.pdf`
- `figures/paper_figures/regional_landcover_panel.pdf`
- `figures/paper_figures/regional_actor_networks.pdf`

## Target journal

*Research Policy* (primary). Backup: *Regional Studies*, *Economic Geography*.

## Open work

- Loudoun pilot situational map (in progress).
- Comparative case-selection memo to formalize the four-case logic.
