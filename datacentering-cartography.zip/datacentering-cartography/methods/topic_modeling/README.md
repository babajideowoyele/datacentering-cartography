# Topic Modeling — News Discourse

**Status:** Methodology specification. No data yet collected.

## Purpose

Surface the framings through which datacentering is publicly negotiated:
*tech enabler*, *energy crisis*, *environmental burden*, *worker precarity*,
*sovereignty*. Track how framings drift across actors and over time.

## Approach

Two complementary models:

- **LDA / dynamic topic models** (Blei et al.) for interpretable, comparable
  topic distributions across long news series.
- **BERTopic / contextual embeddings** for fine-grained framing detection on
  shorter, recent corpora (post-2023, dense).

Both are subordinated to the **CITC cycle** (Miranda et al. 2022): topic
outputs are *patterns*, not findings. They become contributions only after
*lexical framing* — situating patterns in the arenas-of-development discourse.

## Pipeline (intended)

1. **Sampling.** Construct corpus by:
   - Keyword query (`"data center" OR datacenter OR hyperscale ...`)
   - Outlet stratification (FT, WSJ, Reuters; local outlets in case regions;
     trade press: DCD, Data Center Knowledge)
   - Time window: 2015–2026 (decade-spanning)
2. **Preprocessing.** Standard cleaning; named-entity preservation
   (companies, places, regulators).
3. **Synchronic analysis.** Topic models per period.
4. **Diachronic analysis.** Topic drift, actor co-occurrence over time.
5. **Lexical framing.** Cross-reference topic-actor matrices with arena
   participants identified in `methods/situational_maps/`.

## Expected outputs

- `figures/paper_figures/topic_drift_loudoun.pdf`
- `figures/paper_figures/framing_actor_matrix.pdf`
- A reproducible notebook per case region.

## Dependencies (when implemented)

- `gensim` (LDA)
- `bertopic` (contextual)
- `spacy` (NER)
- `pandas`, `numpy`, `matplotlib`

## Open questions

- How to handle non-English regional press (Hyderabad, Luleå)?
- Validation strategy when ground truth is contested by definition?
