# Situational Maps — Clarke (2005) Operationalization

**Status:** Methodology specification. Loudoun pilot in progress (paper).

## Purpose

Translate Clarke's three map types into a reproducible, computationally-aided
workflow that can be applied across datacentering cases.

## The three maps

### 1. Situational map
*All human and nonhuman elements in the situation.*

For datacentering: hyperscalers, grid operators, regulators, communities,
workers, environmentalists; **and** physical infrastructure, zoning law,
electricity prices, satellite imagery, software stacks, cooling water.

Operationalization: a structured YAML file per case, populated from:
- News corpus NER outputs (people, organizations)
- Funding network nodes (financial actors)
- Regulatory filings (legal/policy actors)
- Field observation / secondary literature (community, worker, nonhuman)

### 2. Social worlds / arenas map
*Collective actors and their commitments.*

Operationalization: cluster the situational-map entries into worlds (e.g.
"hyperscaler engineering," "local environmental advocacy," "state grid
regulation"); map their overlapping arenas of negotiation.

### 3. Positional map
*Discursive positions taken — and **not** taken — in the arena.*

Operationalization: cross-tab framings (from topic modeling) against actors
(from situational map) to surface:
- Positions taken with strong support
- Positions taken by few actors (marginalized)
- Positions *logically possible but absent* (Clarke's key innovation)

## Implicated actors

Clarke distinguishes:
- **Silenced actors** — present but excluded from the discourse (e.g.
  affected communities, visa workers).
- **Discursively constructed actors** — invoked in discourse but not present
  (e.g. "the consumer," "future generations").

Operationalization: a separate column in the situational-map YAML flagging
*type of presence* — material/discursive/silenced/absent.

## Expected outputs

- `figures/paper_figures/situational_map_loudoun.pdf` (and per case)
- `figures/paper_figures/positional_map_<case>.pdf`
- A reusable YAML schema (`schema.yaml`) documenting the encoding.

## Dependencies (when implemented)

- `pyyaml`, `pandas`
- `graphviz` or `mermaid` for map rendering
- Hand-curation; this stage resists full automation by design.

## Open questions

- Validation: situational maps are interpretive. What is the
  inter-coder-reliability standard for a multi-author research program?
- How much of the YAML can be bootstrapped by LLMs from the corpus before
  human curation? (Pilot needed.)
