# Satellite Change Detection — Land Conversion & Infrastructure Footprint

**Status:** Methodology specification. No data yet collected.

## Purpose

Make the *physical* footprint of datacentering visible and measurable.
Datacenters are a massive land-use change masked by their architectural
banality (warehouse-form, low silhouette). Satellite time-series surface what
news discourse often misses.

## Approach

Two layers of evidence:

1. **Change detection** — pre/post-construction land conversion at hyperscale
   campus sites.
2. **Footprint inventory** — campus footprints in each case region, including
   committed/permitted-but-unbuilt sites.

## Pipeline (intended)

1. **Site list.** Pull from:
   - Synergy Research Group / DCD published locations (verified)
   - Permit filings in each case jurisdiction
   - Hyperscaler press releases / 10-K geographic disclosures
2. **Imagery.** Sentinel-2 (10 m, free) for coarse change; PlanetScope
   (3 m, licensed) where finer detail is needed.
3. **Change detection.** NDVI time-series + classification (forest → built;
   agriculture → built). Annual mosaics 2015–2026.
4. **Output products.**
   - Per-site before/after panels.
   - Regional aggregation: hectares converted per year, per case.
   - Concurrent electricity transmission infrastructure (substation builds).

## Expected outputs

- `figures/paper_figures/loudoun_landcover_2015_2026.pdf`
- `figures/paper_figures/regional_conversion_rates.pdf`
- A methods notebook documenting the change-detection thresholds and
  validation against ground-truth permit data.

## Dependencies (when implemented)

- Google Earth Engine (Sentinel-2 access, free tier)
- `geemap`, `rasterio`, `geopandas`
- Optional: PlanetScope license (institutional)

## Open questions

- Cooling/water infrastructure is often *off-site*; how to scope the footprint
  boundary defensibly?
- Counterfactual: how to distinguish DC-driven conversion from baseline
  development pressure in growth regions?
