# Social Network Analysis — Hyperlink & Funding Networks

**Status:** Methodology specification. No data yet collected.

## Purpose

Trace **issue alignment** (Marres 2015) and **financial-institutional backbone**
(Crunchbase + 10-K) of the datacentering arena. Two complementary networks:

1. **Hyperlink/citation networks** — who frames the issue, who cites whom, what
   alliances and silences are visible in linking practice.
2. **Funding/board-interlock networks** — who finances datacentering, how
   sovereign capital differs from VC capital, where exits cluster.

## Approach

Following Marres' *affirmative* digital methods stance: hyperlink/citation
structure is treated as evidence of issue formation, not as a noisy proxy for
something else.

Outputs are then situated through **CITC lexical framing**: which network
patterns are theoretically meaningful, which are artefacts of platform design.

## Pipeline (intended)

### Hyperlink network
1. Seed list from topic-modeling outputs (which outlets dominate framings).
2. Crawl outbound links 2 hops; respect `robots.txt`; cache locally.
3. Build directed graph; compute betweenness centrality, modularity (Louvain).
4. Cross-reference communities with arena actors.

### Funding network
1. Pull Crunchbase funding rounds for `data center`, `hyperscale`, `colocation`,
   `AI infrastructure` taxonomies (2010–2026).
2. Pull SEC 10-K filings of public hyperscalers; extract capex line items,
   geographic disclosures, joint ventures.
3. Build temporal bipartite graph (investor → recipient).
4. Compute investor-coupling, geographic clustering, exit pathways.

## Expected outputs

- `figures/paper_figures/hyperlink_communities_<case>.pdf`
- `figures/paper_figures/funding_temporal_<region>.pdf`
- `figures/paper_figures/sovereign_vs_vc_capital.pdf`

## Dependencies (when implemented)

- `networkx`, `igraph`
- `requests`, `scrapy` (crawl)
- Crunchbase API access (institutional)
- `python-edgar` for 10-K extraction

## Open questions

- Crunchbase coverage gaps for non-US, non-Western funding (notably Saudi
  HUMAIN, UAE Stargate financing structures).
- How to represent *implicated actors* (Clarke) — those discursively present
  but not in the link/funding graph?
