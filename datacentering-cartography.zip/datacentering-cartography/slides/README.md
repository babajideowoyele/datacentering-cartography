# Slides

Source and rendered output for the ECR11 talk.

## Files

- `slides.md` — slide source (Pandoc Markdown with YAML front-matter)
- `beamer-tufte-header.tex` — Beamer styling header (Tufte-inspired)
- `slides.pdf` — rendered output

## Re-rendering

From this directory:

```bash
pandoc -t beamer slides.md -o slides.pdf \
  --pdf-engine=xelatex \
  -H beamer-tufte-header.tex \
  --slide-level=2 \
  -V aspectratio=169 \
  -V fontsize=11pt
```

Or via the project Makefile from the repo root:

```bash
make slides
```

## Dependencies

- `pandoc` ≥ 3.0
- `xelatex` (TeX Live)
- `lmodern` package and Latin Modern OpenType fonts

## Editing notes

- `## Heading` starts a new slide (slide-level=2).
- The YAML front-matter generates the title slide automatically.
- Tables use Markdown pipe syntax; rendered with `booktabs`.
- Avoid Unicode glyphs not in Latin Modern (e.g. ↔). Use `&` or text instead.
- For emphasis on a single word, prefer `*word*` (italic) over `<u>` tags.
