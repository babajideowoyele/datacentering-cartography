---
title: "Towards a Cartography of Datacentering"
subtitle: "A Multimodal Research Agenda for Innovation Studies"
author: |
  Babajide Alamu Owoyele \
  DRIFT, Erasmus University Rotterdam | Radboud University Donders Institute
date: "Research Policy 11th ECR Conference · 27 April 2026 · 14:27 BST"
---

## The Empirical Moment

| Metric | Value |
|--------|-------|
| **Hyperscaler capex 2026** | **$750B** |
| Data center electricity (2025) | 485 TWh (17% YoY) |
| AI-specific growth (2025–26) | 50% YoY |
| Hyperscaler capacity by 2031 | 67% of all DC capacity |

*Sources: CreditSights (Feb 2026), IEA Energy & AI Report (April 2026), Synergy Research Group*


## Why Now? The Contested Arena

- **Stargate:** $500B / ~7 GW committed; structural fragmentation (OpenAI, Oracle, SoftBank)
- **PJM electricity:** Capacity auction prices up 833% in one year
- **Maine statewide moratorium:** April 2026
- **Loudoun County eliminates by-right DC:** March 2025
- **DeepSeek V4-Pro (April 2026):** Re-opens Jevons paradox debate


## The Gap in Innovation Studies

- **RP canon covers:** Platforms (Gawer 2014), GPTs, sectoral systems, transitions (Geels)

- **Missing:** Integrative framework for the *infrastructural + methodological* turn in AI-era innovation studies

- **Critical data-center studies exists** in *Big Data & Society*, *Convergence*—but largely outside RP's intellectual canon

- **No unified approach to:** Mapping contested arenas, surfacing implicated actors, operationalizing multimodal evidence


## Theory Layer 1: Arenas of Development

**Jørgensen (2012) — *Research Policy***

"Mapping and navigating transitions: The multi-level perspective compared with arenas of development"

A **flat ontology** starting from actor constellations and their collective engagement, rather than pre-classified structural tiers. **Negotiation** is the fundamental process. Disengages from economic essentialism; allows analysis of political, social, and environmental spheres simultaneously.

**For datacentering:** Identifies hyperscalers, grid operators, communities, workers, regulators, environmentalists as co-constitutive of the arena—not hierarchically ordered.


## Theory Layer 2: Situational Analysis

**Clarke (2005) — STS/Grounded Theory**

*Situational Analysis: Grounded Theory After the Postmodern Turn*

Extends Strauss with three kinds of maps:
1. **Situational maps** of all human/nonhuman elements
2. **Social worlds/arenas maps**
3. **Positional maps**

Key innovation: Identifies two types of **implicated actors**—those silenced/made invisible by power, and those discursively constructed but not present.

**For datacentering:** Maps who decides, who is excluded (communities, visa workers), who is constructed as an actor (energy companies, hyperscalers). Operationalizes arena theory with visual/relational evidence.


## Theory Layer 3: Issue Mapping → Computational Operationalization

**Marres (2015) — *Science, Technology & Human Values***

Shifts controversy analysis to **issue mapping** via digital traces (hyperlinks, hashtags, discourse networks). The "affirmative" approach uses platform traces as an empirical window into issue formation and actor alignment.

**Berente, Seidel & Safadi (2019); Miranda et al. (2022)**
**Computationally Intensive Theory Construction (CITC)**

Operationalizes Marres at scale via four processes: **sampling → synchronic analysis → diachronic analysis → lexical framing.** Patterns become contributions only once situated in a scholarly discourse — preventing both atheoretical pattern-mining and theory unanchored from data.

**For datacentering:** Marres tells us *what* to trace; CITC tells us *how* to trace it rigorously enough to make a theoretical contribution.


## Operationalizing: Multimodal Data Sources

**News discourse (Text).** Topic modeling (LDA). Who frames DC as energy crisis? Tech enabler? Environmental threat?
*Output: topic distributions over time + actor attribution.*

**Satellite + architectural (Images).** Visual infrastructure signatures. Capacity expansion patterns; environmental footprint.
*Output: land conversion maps; temporal change detection.*

**Hyperlink networks (Graph).** Social Network Analysis. News → company sites → regulatory filings → investment platforms.
*Output: betweenness centrality; community detection; alliance maps.*

**Crunchbase + 10-Ks (Structured).** Funding flows, founder networks, board interlocks, capex trajectories, geographic expansion.
*Output: temporal funding networks; geographic diffusion patterns.*

**Methodological integration:** Each modality runs through the CITC cycle (slide 7) — anchoring computational outputs in arenas/situational-analysis discourse.


## Research Agenda: Regional Innovation Systems

**Central Question:** How do hyperscale data-center clusters reshape local productivity spillovers, labor markets, energy regimes, and property relations?

- **Comparative cases:** Loudoun County (US), Luleå (Sweden), Dublin (Ireland), Hyderabad (India)

- **Key metrics:** Employment volatility, wage/skill polarization, electricity price shocks, municipal tax dependence, community displacement

- **Multimodal evidence:** News framing shifts (pro-growth → environmental concern); satellite imagery of land conversion; Crunchbase funding sequences

**Expected result figures:** Temporal topic models (news framing drift); satellite change detection maps; SNA of regional actor networks


## Research Agenda: Sectoral Transformation

**Central Question:** How does hyperscaler vertical integration reshape sectoral innovation systems, especially in AI-using industries?

- **Mechanism:** Hyperscalers (AWS, Google, Meta, Microsoft) increasingly control compute, foundational models, application stacks

- **Effect on startups:** Changed access to infrastructure; new forms of lock-in; shifted innovation incentives

- **Multimodal evidence:** Hyperlink networks of startup funding (who funds via hyperscalers vs. traditional VC?); Crunchbase exit patterns; news coverage of "platform dependency"

**Expected result figures:** Startup funding SNA (hyperscaler-mediated vs. traditional VC); temporal exit outcome shifts; platform dependency topic clusters


## Research Agenda: Policy Sovereignty & Energy

**Central Question:** What policy mix sustains sovereign compute capacity without replicating fossil-fuel dependence or geopolitical lock-in?

- **Cases:** UK AI Growth Zones, EU AI Factories, France €109B investment, Saudi HUMAIN, UAE Stargate

- **Policy instruments:** Tax incentives, grid access, grid-building mandates, renewable energy requirements, labor standards

- **Multimodal evidence:** Policy document discourse analysis; news framing of sovereignty; Crunchbase capital flows to sovereign projects; regulatory filing timelines

**Expected result figures:** Policy discourse SNA (who coordinates sovereign DC development); temporal capital flow networks (by country/funder); policy innovation diffusion curves


## What This Enables: Methodological Innovation

- **Empirical cartography:** Make contested infrastructure transitions *visually traceable and empirically accountable*

- **Multi-arena mapping:** Surface who is included, excluded, silenced, or discursively constructed in datacentering negotiations

- **Toolkit for RP:** A replicable methodology for mapping other contested infrastructure transitions (energy, telecom, rare earths, supply chains)

- **Bridge STS & Innovation Studies:** Connect critical infrastructure scholarship to RP's policy/sectoral canon

- **Open science research infrastructure:** Methodological infrastructure for multimodal evidence synthesis across disciplines


## Why This Lands at Research Policy

### We Use Your Canon
- Jørgensen's arenas (RP 2012)
- Geels' transitions logic
- Marres (who bridges STS & sociology)
- Empirical rigor on sectoral/regional systems

### We Avoid Desk-Rejection Triggers
- Not STS theory preaching
- Testable research questions, not critique
- Multimodal evidence, not humanities hermeneutics
- Innovation policy implications (not just mapping)


## BACKUP — What a Cartography Looks Like

A **situational map** of Loudoun County datacentering arena would show:

**Actors:** Amazon AWS, Google, Meta; Dominion Energy; Loudoun County Board; Sierra Club; Piedmont Environmental Council; workers (visa + local)

**Nonhuman actants:** Electricity grid infrastructure; hyperscale facilities (physical); zoning laws; satellite imagery time-series

**Discourses:** "Tech economic engine" vs. "Environmental burden" vs. "Worker precarity"

**News hyperlinks:** Who cites whom; FT vs. local media framing differences

**Material evidence:** Land conversion rates; electricity price data; tax revenue dependence; community opposition timelines


## Closing Question

**What would innovation studies look like if we treated data infrastructure buildout — both as physical facilities and as research infrastructure — as _foundational_ rather than peripheral?**

A cartography of datacentering is one answer.

*What are others?*
