# Towards a Cartography of Datacentering

**A multimodal research agenda for innovation studies.**

This repository accompanies the paper presented at the Research Policy 11th
Online Conference for Early Career Researchers, 27 April 2026.

> Babajide Alamu Owoyele
> DRIFT, Erasmus University Rotterdam | Radboud University Donders Institute

---

## What this repository is

A research-program scaffold for an emerging cartography of *datacentering* — the
contested, multi-actor process by which hyperscale data-center infrastructure is
produced, sited, contested, and absorbed into regional, sectoral, and
geopolitical innovation systems.

The repository is structured to make every move in the program — from theoretical
framing to data sources to expected figures — independently inspectable and
extensible.

## What this repository is *not*

- It is not (yet) a published dataset or finished paper.
- It is not a generic critical-infrastructure-studies critique. The agenda is
  designed to produce testable propositions consumable by *Research Policy* and
  adjacent journals.
- It is not method-fundamentalist. Methods are subordinate to the arenas and
  questions they illuminate.

---

## Repository layout

```
.
├── slides/         # ECR11 talk source (markdown) + rendered PDF
├── data/           # Data source documentation (no raw data committed)
│   ├── news/           # News corpus collection notes
│   ├── satellite/      # Satellite imagery sources & licensing
│   ├── hyperlinks/     # Hyperlink crawl methodology
│   └── crunchbase/     # Crunchbase + SEC 10-K extraction
├── methods/        # Method module documentation
│   ├── topic_modeling/     # LDA, BERTopic, dynamic topic models
│   ├── sna/                # Social network analysis pipeline
│   ├── situational_maps/   # Clarke (2005) operationalization
│   └── satellite_change/   # Land-cover change detection
├── figures/        # Generated figures
│   ├── slide_figures/      # For talks
│   └── paper_figures/      # For journal submissions
├── papers/         # Working papers and conference submissions
│   ├── ecr11_2026/         # This conference paper
│   └── working/            # Drafts of follow-on papers
├── docs/           # Background notes, glossary, theory primers
├── citations.bib   # Master bibliography
└── README.md
```

---

## Theoretical stack

The cartography is built on three layered frameworks:

1. **Arenas of Development** (Jørgensen 2012, *Research Policy*) — flat ontology
   of actor constellations and negotiation, replacing pre-classified structural
   tiers.
2. **Situational Analysis** (Clarke 2005) — visual mapping of human, nonhuman,
   and *implicated* actors (those silenced or discursively constructed).
3. **Issue Mapping & CITC** (Marres 2015; Berente, Seidel & Safadi 2019;
   Miranda, Berente, Seidel, Safadi & Burton-Jones 2022) — issue mapping via
   digital traces, operationalized through the four-step Computationally
   Intensive Theory Construction cycle: *sampling → synchronic analysis →
   diachronic analysis → lexical framing.*

The full bibliography is in [`citations.bib`](./citations.bib). Theory primers
for each layer are in [`docs/`](./docs/).

---

## Data sources (multimodal)

| Modality   | Source                              | Method                | Output                          |
|------------|-------------------------------------|-----------------------|---------------------------------|
| Text       | News corpora (FT, local, trade)     | Topic modeling (LDA)  | Topic distributions over time   |
| Image      | Sentinel-2, PlanetScope             | Change detection      | Land conversion maps            |
| Graph      | Hyperlink crawl, citation networks  | SNA (centrality, communities) | Alliance maps, framings   |
| Structured | Crunchbase, SEC 10-K, regulatory    | Funding-flow networks | Temporal capital flows          |

Each modality has a methods module under [`methods/`](./methods/) with the
intended pipeline, dependencies, and reproducibility notes.

---

## Research programs

Three independent programs are scaffolded from the same cartographic toolkit:

### 1. Regional Innovation Systems
Comparative cases: **Loudoun County, Luleå, Dublin, Hyderabad.**
Productivity spillovers, labor markets, energy regimes, property relations.

### 2. Sectoral Transformation
How hyperscaler vertical integration reshapes sectoral innovation systems and
startup access to compute and foundational models.

### 3. Policy Sovereignty & Energy
Cases: **UK AI Growth Zones, EU AI Factories, France €109B, Saudi HUMAIN, UAE
Stargate.** Policy mix for sovereign compute without fossil/geopolitical
lock-in.

Each program is sketched in [`papers/working/`](./papers/working/) as a stub with
its central question, expected figures, and indicative cases.

---

## How to read this repo

- For the **3-minute version**: [`slides/slides.pdf`](./slides/) and the README
  you are reading.
- For the **theoretical scaffolding**: [`docs/theory_primer.md`](./docs/) and
  [`citations.bib`](./citations.bib).
- For the **methodological commitments**: any file under [`methods/`](./methods/).
- For the **research programs**: stubs in [`papers/working/`](./papers/working/).

## How to cite

```bibtex
@unpublished{owoyele2026cartography,
  title  = {Towards a Cartography of Datacentering: A Multimodal Research Agenda for Innovation Studies},
  author = {Owoyele, Babajide Alamu},
  year   = {2026},
  note   = {Paper presented at the Research Policy 11th Online Conference for Early Career Researchers, 27 April 2026},
  url    = {https://github.com/<USER>/datacentering-cartography}
}
```

## Contributing

This is an early-stage research program. Issues, references, and methodological
critique are welcome. Please open an issue before submitting a pull request so
that scope can be discussed.

## License

- **Code:** MIT (see `LICENSE`)
- **Text and figures:** CC-BY 4.0 (see `LICENSE-text`)
