# News Corpus

**Status:** Sources identified. Collection pending.

## Sources

| Outlet category   | Examples                                  | Access            |
|-------------------|-------------------------------------------|-------------------|
| Global business   | FT, WSJ, Reuters, Bloomberg               | Institutional sub |
| Tech trade        | Data Center Dynamics (DCD), Data Center Knowledge, The Register, The Information | Mixed / open |
| Local — Loudoun   | Loudoun Times-Mirror, Washington Post (DC bureau) | Mixed |
| Local — Luleå     | Norrländska Socialdemokraten, NSD          | Sub               |
| Local — Dublin    | Irish Times, Irish Independent, Silicon Republic | Mixed |
| Local — Hyderabad | Deccan Chronicle, The Hindu, Telangana Today | Mixed |
| Policy/Regulatory | E&E News, Politico, EurActiv               | Mixed             |

## Time window

2015-01-01 to present, with denser sampling 2022-onward.

## Query strategy

Boolean: `("data center" OR "datacenter" OR "data centre" OR "hyperscale" OR
"colocation") AND (<region terms> OR <hyperscaler names>)`.

Regional terms vary per case study (county, city, neighbourhood granularity).

## Storage

Raw articles will not be committed to this repository (license, IP). The
repository will store:
- Article metadata (URL, date, outlet, headline, author).
- Aggregated counts and topic-model outputs.
- Code to reproduce the corpus from sources.

## Ethics & licensing

- Web scraping subject to each outlet's terms of service.
- Quotation in derived work governed by fair-use / fair-dealing standards.
- Human subjects: not applicable (public published material).

## Open questions

- Cross-language coverage (Swedish, Telugu) — translation pipeline?
- Editorial bias correction across outlets — how, defensibly?
