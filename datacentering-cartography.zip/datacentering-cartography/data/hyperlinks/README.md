# Hyperlink Networks

**Status:** Methodology specification. No crawls run.

## Approach

Following Marres (2015) on issue mapping via digital methods: hyperlink
structure as evidence of issue alignment, not as a noisy proxy for
underlying preference.

## Crawl strategy

- **Seeds.** Top outlets from news topic-modeling outputs (per case region).
- **Depth.** 2 hops outbound, 1 hop inbound (via search-engine querying).
- **Filters.** Exclude social-media share links, tracking domains, CDNs.
- **Rate limiting.** Respect `robots.txt`; randomized delays; identifying
  user-agent.
- **Temporal slicing.** Annual snapshots where archive availability permits
  (Wayback Machine for historical reconstruction).

## Storage

Repository stores:
- Crawl manifests (seed list, exclusion rules, run metadata).
- Edge lists (source URL → target URL, with timestamp).
- Aggregated network outputs (community assignments, centrality scores).

Raw HTML is not retained beyond extraction.

## Ethics

- Public web only.
- No login-walled or personal-data sources.
- No crawling of private platforms (Slack, Discord, etc.).

## Open questions

- Twitter/X access post-2024 collapse: is *any* meaningful issue-mapping still
  feasible from the platform? Likely no — falls back on hashtag-archive
  datasets where available.
- Reddit, Bluesky, Mastodon as partial substitutes — under investigation.
