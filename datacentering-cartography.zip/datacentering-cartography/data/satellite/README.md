# Satellite Imagery

**Status:** Sources identified. Collection pending.

## Sources

| Source       | Resolution | Cost              | Use                    |
|--------------|------------|-------------------|------------------------|
| Sentinel-2   | 10 m       | Free (Copernicus) | Annual change detection|
| Landsat 8/9  | 30 m       | Free (USGS)       | Long historical series |
| PlanetScope  | 3 m        | Licensed          | Site-level detail      |
| Maxar        | 0.3 m      | Licensed          | Architectural detail   |

## Access

- Sentinel-2 + Landsat: via Google Earth Engine (free, institutional).
- PlanetScope: institutional licensing through Planet Labs Education and
  Research Program (application required).

## Storage

Raw imagery will not be committed. Repository stores:
- Site coordinate lists (`sites.geojson`).
- Derived products (NDVI time-series, change masks, before/after panels).
- Code for reproducible imagery pipelines.

## Open questions

- Cloud cover handling in Dublin / Luleå (high latitudes, frequent overcast).
- Imagery licensing for redistribution in published figures (usually allowed
  with attribution; check per provider).
