# Crunchbase + SEC 10-K Filings

**Status:** Sources identified. Extraction pipeline pending.

## Sources

### Crunchbase
- Funding rounds, investors, exits.
- Filtered by industry tags: `data center`, `cloud infrastructure`,
  `colocation`, `AI infrastructure`, `edge computing`.
- Time window: 2010–present.
- Access: institutional API.

### SEC 10-K filings (US public hyperscalers)
- Amazon, Alphabet, Meta, Microsoft, Oracle, IBM.
- Extract: capex by segment, geographic disclosures, joint ventures, lease
  commitments.
- Access: EDGAR (free).

### International / sovereign capital
- Saudi PIF disclosures (HUMAIN).
- UAE Mubadala, ADQ disclosures (Stargate UAE).
- France `France 2030` programme documents.
- UK AI Growth Zone filings.
- *These typically lack 10-K-equivalent disclosure rigour.* Triangulation via
  press releases + regulatory filings is required.

## Extraction pipeline

1. Crunchbase API → filter → temporal funding graph (CSV).
2. EDGAR `python-edgar` → 10-K → structured capex table (CSV).
3. Sovereign sources → manual extraction with versioned source PDFs in
   `data/crunchbase/sovereign_sources/` (PDFs not committed; URLs and
   retrieval dates documented).

## Storage

- Aggregated tables (CSV) committed.
- Raw API dumps not committed (licensing).
- Retrieval scripts versioned.

## Open questions

- Crunchbase coverage for non-US, non-Western funding is patchy. Triangulation
  with Pitchbook / CB Insights / regional sources.
- Sovereign capital disclosure is uneven; how to represent missing-by-design
  edges in the funding graph defensibly?
