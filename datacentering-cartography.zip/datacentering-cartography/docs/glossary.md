# Glossary

A working glossary of terms used in the cartography. Definitions are
operational, not encyclopaedic — they specify how the term is *used here*.

**Arena (of development)** — Following Jørgensen (2012). A site of negotiation
among actor constellations, defined relationally rather than structurally.
Datacentering is a single arena with multiple sub-arenas (regional,
sectoral, sovereign).

**CITC** — Computationally Intensive Theory Construction. Berente, Seidel &
Safadi (2019); Miranda et al. (2022). A four-step cycle (sampling →
synchronic analysis → diachronic analysis → lexical framing) that
disciplines the move from computational pattern to theoretical contribution.

**Datacentering** — Working term for the *process* by which hyperscale
data-center infrastructure is produced, sited, contested, financed, and
absorbed into innovation systems. Distinct from "data center" (the
facility) and "datacenter industry" (the sector).

**Hyperscaler** — Used here for: AWS, Azure (Microsoft), Google Cloud, Meta
infrastructure, Oracle Cloud, IBM Cloud. Sovereign hyperscalers (HUMAIN,
selected EU AI Factory operators) are flagged separately when used.

**Implicated actor** — Clarke (2005). Two types: (a) silenced — present but
excluded from the discourse; (b) discursively constructed — invoked in
discourse but not present.

**Issue mapping** — Marres (2015). The use of digital traces (hyperlinks,
hashtags, citation patterns) as evidence of issue formation in a contested
arena. Distinct from controversy analysis in its *affirmative* stance toward
digital methods.

**Lexical framing** — The CITC step of situating computationally surfaced
patterns within an existing scholarly discourse. The discipline that
distinguishes a contribution from a description.

**Multimodal evidence** — Evidence drawn from more than one data modality —
text, image, graph, structured. The cartography integrates four modalities
(news, satellite, hyperlinks, Crunchbase/10-K).

**Positional map** — Clarke (2005). A map of the discursive positions taken
*and not taken* in an arena. The "not taken" axis is where the framework's
distinctive value lies.

**Situational map** — Clarke (2005). A map of all human and nonhuman elements
in a situation, encoded prior to interpretation.

**Sovereign compute** — Compute capacity controlled by, or politically
accountable to, a national or supranational government. Examples in scope:
UK AI Growth Zones, EU AI Factories, France 2030, Saudi HUMAIN, UAE
Stargate.
