# Theory Primer

A working note for collaborators and curious readers. The cartography rests on
three layered frameworks. This document gives you the *operative* version of
each — what we actually use the framework for — not a full literature review.

## 1. Arenas of Development (Jørgensen 2012)

**Published in:** *Research Policy* 41(6), 2012.

**Core move:** Replace the structural tiers of the multi-level perspective
(landscape / regime / niche) with a *flat ontology* of actor constellations
engaged in collective negotiation.

**Why we use it:** Datacentering is a contested arena *now*. Tier-based
analysis presupposes that the regime is settled and the niche is challenger.
For datacentering, neither premise holds: hyperscalers are simultaneously
incumbent (in cloud) and challenger (in grid politics). Arenas avoid
prejudging the structural position.

**Operational consequence:** When mapping a case, we list actors first and
*then* describe their commitments — not the reverse.

## 2. Situational Analysis (Clarke 2005)

**Published in:** Sage book, *Situational Analysis: Grounded Theory After the
Postmodern Turn*.

**Core move:** Extend Strauss's grounded theory with three map types —
situational maps (all elements), social worlds/arenas maps (collective
actors), and positional maps (discursive positions). Crucially: include
**implicated actors** — those silenced by power *and* those discursively
constructed but not present.

**Why we use it:** Innovation studies is good at the actors who show up to
the meeting. It is less good at the workers, communities, and futures
*invoked* in policy documents but not at the table. Clarke gives us a
disciplined way to register their absence.

**Operational consequence:** Every case study has a YAML schema flagging
*type of presence* — material, discursive, silenced, absent.

See `methods/situational_maps/`.

## 3. Issue Mapping (Marres 2015) + CITC (Berente et al. 2019; Miranda et al. 2022)

**Published in:** *Science, Technology, & Human Values* 40(5); *Information
Systems Research* 30(1); *MIS Quarterly* 46(2).

**Core move (Marres):** Treat digital traces — hyperlinks, hashtags, citation
patterns — as evidence of issue formation, not as noisy proxies for
underlying preference. The "affirmative" stance: digital platforms have
agency; use that as a window.

**Core move (CITC):** Discipline the move from *pattern* to *theoretical
contribution* through four steps: sampling → synchronic analysis → diachronic
analysis → **lexical framing**. The last step is the discipline that prevents
both atheoretical pattern-mining and theory unanchored from data.

**Why we use both:** Marres tells us *what* to trace. CITC tells us *how* to
trace it rigorously. The combination is the methodological spine of the
cartography.

**Operational consequence:** Topic models, SNA outputs, and satellite change
detections are *patterns*. They become contributions only after lexical
framing — situating them within arenas and innovation-systems discourse.

See `methods/topic_modeling/`, `methods/sna/`.

---

## Why this stack and not others?

- **Why not pure MLP/transitions theory?** Because datacentering's structural
  position is unsettled. MLP wants to know if AWS is a regime actor or a
  niche actor. The honest answer is "both, depending on the arena."
- **Why not pure STS / critical infrastructure studies?** Because the goal is
  testable propositions consumable by *Research Policy*, not critique alone.
  The CITC layer is the discipline that distinguishes patterns from
  contributions.
- **Why not platform theory (Gawer 2014)?** Platform theory is *part of* the
  sectoral-transformation paper (Working Paper 2). It addresses one arena
  (sectoral integration), not the multi-arena cartography.

---

## What this stack does **not** do

- It does not adjudicate normative questions about whether datacentering is
  good or bad. It maps the arena; political-philosophical assessment is a
  separate move.
- It does not produce real-time policy advice. The cartography is a research
  programme; policy translation is downstream of it.
- It does not replace traditional econometric work on AI productivity or
  spillovers. It complements it by giving the *contextual scaffolding* in
  which those measurements take meaning.
